class StyleMixin:
    def set_style_instance(self, style):
        self.style = style

    def apply_theme(self, theme_name):
        self.style.theme_use(theme_name)

        style_settings = {
            "Custom.TLabel": {"background": "#f9f9f9", "foreground": "#000000"},
            "TCheckbutton": {"background": "#ffffff"},
            "Custom.TCheckbutton": {"background": "#f0f0f0"},
            "Settings.TCheckbutton": {"background": "#f9f9f9"},
            "Custom.TButton": {"background": "#f9f9f9"},
            "TNotebook": {"background": "#f0f0f0", "tabmargins": [0, 10, 0, 0]},
            "TNotebook.tab": {"background": "#f3f3f3"},
            "TFrame": {"background": "#f9f9f9"},
            "TLabelframe": {"background": "#f9f9f9"},
            "TLabelframe.Label": {"background": "#f9f9f9"},
        }

        for style_name, options in style_settings.items():
            self.style.configure(style_name, **options)

        self.style.map("TNotebook.Tab", background=[("selected", "#f9f9f9")])
