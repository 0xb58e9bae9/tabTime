APP_NAME = "PrintBot"
APP_SUBTITLE = "BC受付自動印刷"
APP_VERSION = "1.0.0"
APP_CREATOR = "TPTQA 呉地大輔"
EMAIL_ADDRESS = "daisuke.kurechi.zd@fujifilm.com"
LAST_UPDATE = "2025/04/30"


LOGIN_URL = ""

MS_EDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

ICON_PATH = "./images/python_icon_16_256.ico"
SETTINGS_ICO_PATH = "./images/settings_icon_16x16.ico"

PRINT_TARGET_DATA = {
    "FSP": ("K11K2", "K11K4"),
    "#7": ("K11J2", "K11J5"),
    "#8": ("K11J8", "K11J9"),
    # "基材識別票": ("K11K2", "K11J2", "K11J5", "K11J8"),
}

BASE_DPI = 96
LOGO_SIZE = 36
SETTINGS_ICO_SIZE = 16

DATE_RANGE = 7
START_DATE_DEFAULT = 0
END_DATE_DEFAULT = DATE_RANGE - 1

INPUT_LIMIT = 14

CHECKBOX_DEFAULT = 1

PROGRESSBAR_SPEED = 10
