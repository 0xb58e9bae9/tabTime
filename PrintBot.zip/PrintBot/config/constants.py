APP_NAME = "PrintBot"
APP_SUBTITLE = "BC受付自動印刷"
APP_VERSION = "0.1.0"
APP_CREATOR = "Daisuke Kurechi"
EMAIL_ADDRESS = "example@example.com"
LAST_UPDATE = "2025/04/26"


LOGIN_URL = ""

ICON_PATH = "./images/python_icon_16_256.ico"
LOGO_PATH = "./images/python_logo_48x48.png"
SETTINGS_PNG_PATH = "./images/settings_icon_16x16.png"
SETTINGS_ICO_PATH = "./images/settings_icon_16x16.ico"

PRINT_TARGET_DATA = {
    "FSP": ("K11K2", "K11K4"),
    "#7": ("K11J2", "K11J5"),
    "#8": ("K11J8", "K11J9"),
    "基材識別票": ("K11K2", "K11J2", "K11J5", "K11J8"),
}

DATE_RANGE = 7
START_DATE_DEFAULT = 0
END_DATE_DEFAULT = DATE_RANGE - 1

INPUT_LIMIT = 14

CHECKBOX_DEFAULT = 1

PROGRESSBAR_SPEED = 10
