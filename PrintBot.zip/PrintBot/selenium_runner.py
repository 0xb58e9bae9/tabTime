import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--user", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--date", nargs="*", default=[])
    parser.add_argument("--targets", nargs="*", default=[])
    parser.add_argument("--labels", nargs="*", default=[])

    args = parser.parse_args()

    # test
    print(f"userId: {args.user}")
    print(f"password: {args.password}")
    print(f"date: {args.date}")
    print(f"targets: {args.targets}")
    print(f"labels: {args.labels}")


if __name__ == "__main__":
    main()
