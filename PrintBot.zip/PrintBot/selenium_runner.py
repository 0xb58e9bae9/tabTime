import sys
import os
import time

from selenium import webdriver
from selenium.webdriver.ie.service import Service
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import config.constants as constants
from utils.window_helper import hide_browser_window
from utils.common import get_setting, get_bool_setting, save_password


def get_driver_path():
    if hasattr(sys, "_MEIPASS"):
        base_dir = sys._MEIPASS
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, "IEDriverServer.exe")


def main(user_id, password, selected_date_list, selected_values):
    driver_path = get_driver_path()

    ie_options = Options()
    ie_options.attach_to_edge_chrome = True
    ie_options.edge_executable_path = constants.MS_EDGE_PATH

    driver_service = Service(executable_path=driver_path)
    driver = webdriver.Ie(service=driver_service, options=ie_options)

    # show_browser_windowをsettings.iniから取得
    show_browser_window = get_bool_setting(
        "Execution", "show_browser_window", fallback=True
    )

    try:
        if not show_browser_window:
            hide_browser_window(driver)

        driver.get(constants.LOGIN_URL)

        # ログイン画面
        input_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "userId"))
        )
        input_field.send_keys(user_id)

        input_field = driver.find_element(By.NAME, "userPwd")
        input_field.send_keys(password)

        login_button = driver.find_element(By.NAME, "loginButton")
        login_button.click()

        # メニュー選択画面
        dropdown_list = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "menuList"))
        )
        dropdown_list.click()

        # 設定値を読み込み、ログイン成功でパスワード保存
        if get_bool_setting("Login", "save_password", fallback=False):
            save_password(password)

        for _ in range(8):
            dropdown_list.send_keys(Keys.ARROW_DOWN)
        dropdown_list.send_keys(Keys.ENTER)

        # 帳票検索画面
        dropdown_list = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "reportList"))  # 帳票
        )
        dropdown_list.click()

        for _ in range(5):
            dropdown_list.send_keys(Keys.ARROW_DOWN)
        dropdown_list.send_keys(Keys.ENTER)

        for date in selected_date_list:
            for target in selected_values:
                input_field = driver.find_element(By.NAME, "locationCode")  # 受渡場所
                input_field.send_keys(Keys.CONTROL, "a")
                input_field.send_keys(Keys.BACKSPACE)
                input_field.send_keys(target)

                input_field = driver.find_element(
                    By.NAME, "proDateFrom"
                )  # 納期（開始日）
                input_field.send_keys(Keys.CONTROL, "a")
                input_field.send_keys(Keys.BACKSPACE)
                input_field.send_keys(date)

                input_field = driver.find_element(
                    By.NAME, "proDateTo"
                )  # 納期（終了日）
                input_field.send_keys(Keys.CONTROL, "a")
                input_field.send_keys(Keys.BACKSPACE)
                input_field.send_keys(date)

                search_button = driver.find_element(By.NAME, "searchButton")  # 検索[F4]
                search_button.click()

                # 帳票出力画面
                # checkbox0があるかないか確認 でelseに下のifを追加
                if not get_bool_setting("Execution", "skip_if_empty", fallback=True):
                    print_button = driver.find_element(
                        By.NAME, "printButton"
                    )  # 出力[F12]
                    print_button.click()

                    time.sleep(5)

                return_button = driver.find_element(By.NAME, "clearReturn")  # 戻る[F8]
                return_button.click()

                try:
                    WebDriverWait(driver, 10).until(EC.alert_is_present())
                    alert = driver.switch_to.alert
                    alert.accept()
                except:
                    print("アラートが表示されませんでした")

    finally:
        try:
            logout_button = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.NAME, "logout"))
            )
            logout_button.click()

            WebDriverWait(driver, 10).until(EC.alert_is_present())
            alert = driver.switch_to.alert
            alert.accept()
        except Exception as e:
            print(f"ログアウト処理中にエラー発生: {e}")

        time.sleep(2)

        # Edgeを終了
        driver.quit()


if __name__ == "__main__":
    print("直接実行されましたが、通常はimportして使います")
