import time
import tkinter as tk
from ctypes import windll

from PIL import Image, ImageTk
from selenium.webdriver.remote.webdriver import WebDriver


def set_per_monitor_dpi_awareness() -> None:
    """DPIスケーリングモードを Per-Monitor DPI Aware に設定する"""
    try:
        windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass


def get_dpi_scaling(root: tk.Tk | tk.Toplevel, base_dpi: int = 96) -> float:
    """現在のDPIに基づくスケーリング倍率を返す（96dpi基準）

    Args:
        root: Tkinterのルートウィンドウ
        base_dpi: 基準とするDPI（デフォルトは96）

    Returns:
        float: DPIスケーリング倍率
    """
    dpi = root.winfo_fpixels("1i")
    return dpi / base_dpi


def load_scaled_icon(path: str, base_size: int, root: tk.Tk) -> ImageTk.PhotoImage:
    """DPIスケーリング対応のアイコン画像を読み込む

    Args:
        path (str): 画像ファイルのパス（.ico, .png など）
        base_size (int): 96dpi基準でのアイコンの基準サイズ（ピクセル）
        root (tk.Tk): DPI取得のためのルートウィンドウ

    Returns:
        ImageTk.PhotoImage: Tkinterで使える画像オブジェクト
    """
    scale = get_dpi_scaling(root)
    size = int(base_size * scale)

    image = Image.open(path)
    resized = image.resize((size, size), Image.LANCZOS)

    return ImageTk.PhotoImage(resized)


def show_and_center_window(window: tk.Tk | tk.Toplevel) -> None:
    """ウィンドウ生成時のちらつきを防ぎ中央に表示"""
    window.withdraw()

    def center_and_show():
        window.update_idletasks()

        width = window.winfo_reqwidth()
        height = window.winfo_reqheight()

        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        window.geometry(f"+{x}+{y}")
        window.deiconify()

    window.after(0, center_and_show)


def hide_browser_window(driver: WebDriver) -> None:
    """ブラウザウィンドウをできるだけ完全に非表示にする"""
    try:
        time.sleep(1)
        driver.set_window_position(-3000, 0)
        driver.minimize_window()
    except Exception as e:
        print(f"ウィンドウ非表示失敗: {e}")
