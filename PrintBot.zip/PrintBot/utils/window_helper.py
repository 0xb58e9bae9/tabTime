import tkinter as tk
from ctypes import windll


def set_per_monitor_dpi_awareness() -> None:
    """DPIスケーリングモードを Per-Monitor DPI Aware に設定する"""
    try:
        windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass


def show_and_center_window(window: tk.Tk | tk.Toplevel) -> None:
    """ウィンドウ生成時のちらつきを防ぎ中央に表示"""
    window.withdraw()

    def center_and_show():
        window.update_idletasks()

        width = window.winfo_reqwidth()
        height = window.winfo_reqheight()

        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        window.geometry(f"+{x}+{y}")
        window.deiconify()

    window.after(0, center_and_show)
