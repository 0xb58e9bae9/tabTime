import base64
import configparser
import getpass
import locale
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

import config.constants as constants


if getattr(sys, "frozen", False):
    # PyInstallerでビルドされた場合、実行ファイルのパスを取得
    base_path = Path(sys.executable).resolve().parent
else:
    # スクリプトが実行されている場合、スクリプトのパスを取得
    base_path = Path(__file__).resolve().parent.parent

CONFIG_PATH = base_path / "config" / "settings.ini"
config = configparser.ConfigParser()
config.read(CONFIG_PATH, encoding="utf-8")


def get_setting(section: str, key: str, fallback=None) -> str | None:
    """INIファイルから設定値を取得する"""
    return config.get(section, key, fallback=fallback)


def set_setting(section: str, key: str, value: str) -> None:
    """INIファイルに設定値を保存する"""
    if not config.has_section(section):
        config.add_section(section)
    config.set(section, key, value)

    # ディレクトリが存在しない場合は作成
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        config.write(f)


def get_app_title() -> str:
    """デフォルトのアプリケーションタイトルを取得"""
    return constants.APP_NAME


def get_user_id() -> str:
    """コンピューターのユーザー名からユーザーIDを取得する"""
    return getpass.getuser()


def greet(name) -> str:
    """ユーザーに挨拶する"""
    message = (
        f"{name}さん、おつかれさまです！\n"
        "BC受付のパスワードと印刷範囲を入力してください。"
    )
    print(message)
    return message


def generate_date_data() -> list:
    """日付リストの生成"""
    locale.setlocale(locale.LC_ALL, "ja_JP.UTF-8")

    today = datetime.today()
    data = []

    for i in range(constants.DATE_RANGE):
        date = today + timedelta(days=i)
        display = date.strftime("%#m月%#d日（%a）")
        value = date.strftime("%y/%m/%d")
        data.append({"display": display, "value": value})

    return data


def open_printers_settings() -> None:
    """Windowsの設定画面「プリンターとスキャナー」を開く"""
    subprocess.run(["start", "ms-settings:printers"], shell=True)
