import base64
import configparser
import getpass
import locale
import subprocess
import sys
import os
from datetime import datetime, timedelta
from pathlib import Path

import config.constants as constants


# --- 初期設定 ---
appdata_raw = os.getenv("APPDATA")
if appdata_raw is None:
    raise RuntimeError("APPDATA 環境変数が取得できませんでした")

appdata_dir = Path(appdata_raw) / "PrintBot"
user_settings_path = appdata_dir / "settings.ini"

# Nuitka onefile対応パス
if hasattr(sys, "_MEIPASS"):
    default_base_path = Path(sys._MEIPASS)
else:
    default_base_path = Path(__file__).resolve().parent.parent

default_settings_path = default_base_path / "config" / "settings.ini"

# --- 設定ファイル決定 ---
if user_settings_path.exists():
    CONFIG_PATH = user_settings_path
else:
    CONFIG_PATH = default_settings_path

# --- 設定読み込み ---
config = configparser.ConfigParser()
config.read(CONFIG_PATH, encoding="utf-8")


def get_setting(section: str, key: str, fallback=None):
    """設定値を文字列で取得"""
    try:
        return config.get(section, key)
    except (configparser.NoSectionError, configparser.NoOptionError):
        return fallback


def get_bool_setting(section: str, key: str, fallback: bool = False) -> bool:
    """設定値をboolで取得"""
    try:
        return config.getboolean(section, key)
    except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
        return fallback


# --- 設定保存 ---
def set_setting(section, key, value):
    """設定値を更新して保存（ユーザー設定のみ書き込み）"""
    # 書き込み対象は必ず user_settings_path
    appdata_dir.mkdir(parents=True, exist_ok=True)
    user_config = configparser.ConfigParser()
    if user_settings_path.exists():
        user_config.read(user_settings_path, encoding="utf-8")
    else:
        user_config.read(default_settings_path, encoding="utf-8")

    if not user_config.has_section(section):
        user_config.add_section(section)

    user_config.set(section, key, str(value))

    with open(user_settings_path, "w", encoding="utf-8") as f:
        user_config.write(f)


def save_password(raw_password: str) -> None:
    """パスワードをBase64でエンコードしてINIファイルに保存する"""
    encoded_password = base64.b64encode(raw_password.encode("utf-8")).decode("utf-8")
    set_setting("Login", "stored_password", encoded_password)


def load_password() -> str:
    """ "INIファイルからパスワードをデコードして返す"""
    encoded_password = get_setting("Login", "stored_password", "")
    if encoded_password:
        return base64.b64decode(encoded_password.encode("utf-8")).decode("utf-8")
    return ""


def load_user_id(user_id: str | None = None) -> str:
    """custom_user_idがあれば優先し、なければ引数user_idまたはシステムIDを返す"""
    custom_user_id = get_setting("Login", "custom_user_id", "")
    if custom_user_id:
        return custom_user_id
    if user_id:
        return user_id
    return get_user_id()


def get_user_id() -> str:
    """コンピューターのユーザー名からユーザーIDを取得する"""
    return getpass.getuser()


def get_app_title() -> str:
    """デフォルトのアプリケーションタイトルを取得"""
    return constants.APP_NAME


def greet(name) -> str:
    """ユーザーに挨拶する"""
    message = (
        f"{name}さん、おつかれさまです！\n"
        "BC受付のパスワードと印刷範囲を入力してください。"
    )
    print(message)
    return message


def generate_date_data() -> list:
    """日付リストの生成"""
    locale.setlocale(locale.LC_ALL, "ja_JP.UTF-8")

    today = datetime.today()
    data = []

    for i in range(constants.DATE_RANGE):
        date = today + timedelta(days=i)
        display = date.strftime("%#m月%#d日（%a）")
        value = date.strftime("%y/%m/%d")
        data.append({"display": display, "value": value})

    return data


def open_printers_settings() -> None:
    """Windowsの設定画面「プリンターとスキャナー」を開く"""
    subprocess.run(["start", "ms-settings:printers"], shell=True)
