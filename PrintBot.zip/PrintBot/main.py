import config.constants as constants
from utils.common import get_user_id
from gui import MainWindow


def run_gui():
    app = MainWindow(
        user_id=get_user_id(), title=f"{constants.APP_NAME} - {constants.APP_SUBTITLE}"
    )
    app.run()


if __name__ == "__main__":
    run_gui()
