class StyleMixin:
    def set_style_instance(self, style):
        self.style = style

    def apply_theme(self, theme_name):
        self.style.theme_use(theme_name)
        self.style.configure(
            "Custom.TLabel", background="#f0f0f0", foreground="#000000"
        )
        self.style.configure(
            "Custom.TCheckbutton", background="#f0f0f0", foreground="#000000"
        )
        self.style.configure("Copy.TButton", width=18)
