class StyleMixin:
    def set_style_instance(self, style):
        self.style = style

    def apply_theme(self, theme_name):
        self.style.theme_use(theme_name)
        self.style.configure(
            "Custom.TLabel", background="#f9f9f9", foreground="#000000"
        )
        self.style.configure("TCheckbutton", background="#ffffff")
        self.style.configure("Custom.TCheckbutton", background="#f0f0f0")
        self.style.configure("Settings.TCheckbutton", background="#f9f9f9")
        self.style.configure("Custom.TButton", background="#f9f9f9")
        self.style.configure(
            "TNotebook", background="#f0f0f0", tabmargins=[0, 10, 0, 0]
        )
        self.style.configure("TNotebook.tab", background="#f3f3f3")
        self.style.map("TNotebook.Tab", background=[("selected", "#f9f9f9")])
        self.style.configure("TFrame", background="#f9f9f9")
        self.style.configure("TLabelframe", background="#f9f9f9")
        self.style.configure("TLabelframe.Label", background="#f9f9f9")
