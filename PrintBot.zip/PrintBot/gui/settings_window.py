import tkinter as tk
import tkinter.ttk as ttk

import config.constants as constants
from utils.common import (
    get_setting,
    get_bool_setting,
    set_setting,
    open_printers_settings,
)
from gui.style_mixin import StyleMixin


class SettingsWindow(tk.Toplevel, StyleMixin):
    def __init__(self, master, is_opening=None, on_settings_close=None):
        super().__init__(master)
        self.withdraw()
        self.is_opening_callback = is_opening
        self.on_settings_close_callback = on_settings_close

        self.protocol("WM_DELETE_WINDOW", self.on_settings_close)
        self.iconbitmap(constants.SETTINGS_ICO_PATH)
        self.resizable(False, False)
        self.title(f"{constants.APP_NAME} - 設定")

        style = ttk.Style(self)
        self.set_style_instance(style)
        self.apply_theme("vista")

        self.build_widgets()
        self.load_settings()
        self.layout_widgets()
        self.bind_events()

        self.after(0, lambda: self._place_on_top_of_master(master))

    def build_widgets(self):
        self.notebook = ttk.Notebook(self, style="TNotebook")

        self.general_frame = ttk.Frame(self.notebook, style="TFrame")
        self.app_info_frame = ttk.Frame(self.notebook, style="TFrame")

        self.bottom_frame = ttk.Frame(self, style="Gray.TFrame")

        self.build_general_tab()
        self.build_app_info_tab()
        self.build_bottom_buttons()

        self.notebook.add(self.general_frame, text=" 一般     ")
        self.notebook.add(self.app_info_frame, text=" 情報    ")

    def build_general_tab(self):
        self.login_info_lf = ttk.Labelframe(self.general_frame, text="BC受付のログイン")
        self.checkbox1_var = tk.BooleanVar()
        self.checkbox2_var = tk.BooleanVar()
        self.checkbox2_var.trace_add("write", self.toggle_user_id_entry)
        self.input_user_id_var = tk.StringVar()

        self.checkbox1 = ttk.Checkbutton(
            self.login_info_lf,
            text="ログインに成功した場合、パスワードを保存して次回から自動入力する",
            variable=self.checkbox1_var,
            style="Settings.TCheckbutton",
        )

        self.checkbox2 = ttk.Checkbutton(
            self.login_info_lf,
            text="ユーザーIDを変更する (既定のユーザーID : Windows のユーザー名)",
            variable=self.checkbox2_var,
            style="Settings.TCheckbutton",
        )

        self.input_user_id = tk.Entry(
            self.login_info_lf,
            width=36,
            textvariable=self.input_user_id_var,
            insertwidth=1,
            borderwidth=0,
            highlightthickness=1,
            highlightbackground="#8d8d8d",
            highlightcolor="#0078d4",
        )

        self.print_target_lf = ttk.Labelframe(self.general_frame, text="印刷範囲の設定")
        self.checkbox3_var = tk.BooleanVar()
        self.checkbox3_var.trace_add("write", self.toggle_date_range)

        self.checkbox3 = ttk.Checkbutton(
            self.print_target_lf,
            text="アプリケーション起動時の日付範囲を変更する",
            variable=self.checkbox3_var,
            style="Settings.TCheckbutton",
        )

        self.range_frame = ttk.Frame(self.print_target_lf)
        self.start_spinbox_var = tk.StringVar()
        self.end_spinbox_var = tk.StringVar()
        self.start_spinbox_var.trace_add("write", self.validate_spinbox_range)
        self.end_spinbox_var.trace_add("write", self.validate_spinbox_range)

        self.date_range_label1 = ttk.Label(
            self.range_frame, text="開始日: 当日から", style="Custom.TLabel"
        )
        self.start_spinbox = tk.Spinbox(
            self.range_frame,
            from_=0,
            to=6,
            width=2,
            textvariable=self.start_spinbox_var,
        )
        self.date_range_label2 = ttk.Label(
            self.range_frame, text="日目 / 終了日: 当日から", style="Custom.TLabel"
        )
        self.end_spinbox = tk.Spinbox(
            self.range_frame, from_=0, to=6, width=2, textvariable=self.end_spinbox_var
        )
        self.date_range_label3 = ttk.Label(
            self.range_frame, text="日目", style="Custom.TLabel"
        )

        self.execute_lf = ttk.Labelframe(
            self.general_frame, text="印刷実行時の設定 (次回起動時に反映)"
        )
        self.checkbox5_var = tk.BooleanVar()
        self.checkbox6_var = tk.BooleanVar()

        self.checkbox5 = ttk.Checkbutton(
            self.execute_lf,
            text="納入予定品がない場合、その印刷をスキップする",
            variable=self.checkbox5_var,
            style="Settings.TCheckbutton",
        )

        self.checkbox6 = ttk.Checkbutton(
            self.execute_lf,
            text="自動操作中のウィンドウを表示する",
            variable=self.checkbox6_var,
            style="Settings.TCheckbutton",
        )

        self.printer_lf = ttk.Labelframe(self.general_frame, text="プリンター設定")
        self.label1 = ttk.Label(
            self.printer_lf,
            text="Windows の印刷設定を開いて、既定のプリンターなどを設定します。",
            style="Custom.TLabel",
        )
        self.printer_settings_button = ttk.Button(
            self.printer_lf,
            text="プリンター設定を開く",
            style="Custom.TButton",
            command=open_printers_settings,
        )

    def build_app_info_tab(self):
        self.app_info_lf = ttk.Labelframe(
            self.app_info_frame, text="このアプリケーションについて"
        )
        self.app_info_lf.columnconfigure(2, weight=1)

        self.label_app_name_label = ttk.Label(
            self.app_info_lf, text="アプリケーション名 :", style="Custom.TLabel"
        )
        self.label_app_name = ttk.Label(
            self.app_info_lf, text=constants.APP_NAME, style="Custom.TLabel"
        )

        self.label_version_label = ttk.Label(
            self.app_info_lf, text="バージョン :", style="Custom.TLabel"
        )
        self.label_version = ttk.Label(
            self.app_info_lf, text=constants.APP_VERSION, style="Custom.TLabel"
        )

        self.label_update_label = ttk.Label(
            self.app_info_lf, text="最終更新日 :", style="Custom.TLabel"
        )
        self.label_update = ttk.Label(
            self.app_info_lf, text=constants.LAST_UPDATE, style="Custom.TLabel"
        )

        self.label_creator_label = ttk.Label(
            self.app_info_lf, text="作成者 :", style="Custom.TLabel"
        )
        self.label_creator = ttk.Label(
            self.app_info_lf, text=constants.APP_CREATOR, style="Custom.TLabel"
        )

        self.label_email_label = ttk.Label(
            self.app_info_lf, text="メールアドレス :", style="Custom.TLabel"
        )
        self.label_email = ttk.Label(
            self.app_info_lf, text=constants.EMAIL_ADDRESS, style="Custom.TLabel"
        )

        self.address_button = ttk.Button(
            self.app_info_lf,
            width=18,
            text="メールアドレスをコピー",
            command=self.copy_to_clipboard,
            style="Custom.TButton",
        )

    def build_bottom_buttons(self):
        self.save_button = ttk.Button(
            self.bottom_frame, text="OK", command=self.save_settings
        )
        self.close_button = ttk.Button(
            self.bottom_frame, text="キャンセル", command=self.on_settings_close
        )

    def layout_widgets(self):
        self.notebook.pack(fill="both", expand=True, padx=7, ipady=12)
        self.bottom_frame.pack(side="bottom", fill="x", padx=6, pady=8)
        self.close_button.pack(side="right", ipadx=8)
        self.save_button.pack(side="right", padx=6, ipadx=10)

        self.login_info_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(7, 0), ipadx=12, ipady=5
        )
        self.checkbox1.pack(anchor="w", padx=(19, 0), pady=(7, 2))
        self.checkbox2.pack(anchor="w", padx=(19, 0), pady=(7, 2))
        self.input_user_id.pack(anchor="w", padx=(38, 0), pady=2)

        self.print_target_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(7, 0), ipadx=12, ipady=5
        )
        self.checkbox3.grid(row=0, column=0, sticky="w", padx=(19, 0), pady=(7, 2))
        self.range_frame.grid(row=1, column=0, sticky="w", padx=(36, 0), pady=2)
        self.date_range_label1.pack(side="left")
        self.start_spinbox.pack(side="left", padx=(2, 1))
        self.date_range_label2.pack(side="left")
        self.end_spinbox.pack(side="left", padx=(2, 1))
        self.date_range_label3.pack(side="left")

        self.execute_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(7, 0), ipadx=12, ipady=5
        )
        self.checkbox5.pack(anchor="w", padx=(19, 0), pady=(7, 2))
        self.checkbox6.pack(anchor="w", padx=(19, 0), pady=(7, 2))

        self.printer_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(0, 10), ipadx=12, ipady=6
        )
        self.label1.pack(fill="x", padx=(19, 0), pady=(7, 2))
        self.printer_settings_button.pack(side="right", padx=10, pady=(2, 5), ipadx=8)

        self.app_info_lf.pack(
            side="top",
            fill="x",
            expand=False,
            padx=(15, 17),
            pady=(10, 0),
            ipadx=12,
            ipady=5,
        )
        self.label_app_name_label.grid(
            row=0, column=0, sticky="w", padx=(19, 0), pady=2
        )
        self.label_app_name.grid(row=0, column=1, sticky="w", padx=(6, 0))

        self.label_version_label.grid(row=1, column=0, sticky="w", padx=(19, 0), pady=2)
        self.label_version.grid(row=1, column=1, sticky="w", padx=(6, 0))

        self.label_update_label.grid(row=2, column=0, sticky="w", padx=(19, 0), pady=2)
        self.label_update.grid(row=2, column=1, sticky="w", padx=(6, 0))

        self.label_creator_label.grid(row=3, column=0, sticky="w", padx=(19, 0), pady=2)
        self.label_creator.grid(row=3, column=1, sticky="w", padx=(6, 0))

        self.label_email_label.grid(row=4, column=0, sticky="w", padx=(19, 0), pady=2)
        self.label_email.grid(row=4, column=1, sticky="w", padx=(6, 0))

        self.address_button.grid(row=5, column=1, sticky="w", padx=(6, 0), pady=(8, 2))

    def bind_events(self):
        self.start_spinbox.bind("<Key>", self.disable_key_input)
        self.end_spinbox.bind("<Key>", self.disable_key_input)
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

    def toggle_user_id_entry(self, *args):
        self.input_user_id.config(
            state="normal" if self.checkbox2_var.get() else "disabled"
        )

    def toggle_date_range(self, *args):
        state = "normal" if self.checkbox3_var.get() else "disabled"
        for widget in [
            self.date_range_label1,
            self.start_spinbox,
            self.date_range_label2,
            self.end_spinbox,
            self.date_range_label3,
        ]:
            widget.config(state=state)

    def disable_key_input(self, event):
        return "break"

    def validate_spinbox_range(self, *args):
        try:
            start = int(self.start_spinbox_var.get())
            end = int(self.end_spinbox_var.get())
            if end < start:
                self.end_spinbox_var.set(str(start))
        except ValueError:
            pass

    def copy_to_clipboard(self):
        text = constants.EMAIL_ADDRESS
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update()
        self.address_button.config(text="コピーしました", state="disabled")
        self.after(2000, self.reset_button)

    def reset_button(self):
        self.address_button.config(text="メールアドレスをコピー", state="normal")

    def load_settings(self):
        self.checkbox1_var.set(
            get_bool_setting("Login", "save_password", fallback=False)
        )
        self.checkbox2_var.set(
            get_bool_setting("Login", "change_user_id", fallback=False)
        )
        self.input_user_id_var.set(get_setting("Login", "custom_user_id", fallback=""))

        self.checkbox3_var.set(
            get_bool_setting("Startup", "change_date_range", fallback=False)
        )

        self.start_spinbox_var.set(get_setting("Startup", "start_offset", fallback="0"))
        self.end_spinbox_var.set(get_setting("Startup", "end_offset", fallback="0"))

        self.checkbox5_var.set(
            get_bool_setting("Execution", "skip_if_empty", fallback=False)
        )
        self.checkbox6_var.set(
            get_bool_setting("Execution", "show_browser_window", fallback=False)
        )

    def save_settings(self):
        set_setting("Login", "save_password", str(self.checkbox1_var.get()))
        if not self.checkbox1_var.get():
            set_setting("Login", "stored_password", "")
        set_setting("Login", "change_user_id", str(self.checkbox2_var.get()))
        set_setting(
            "Login",
            "custom_user_id",
            self.input_user_id_var.get() if self.checkbox2_var.get() else "",
        )
        set_setting("Startup", "change_date_range", str(self.checkbox3_var.get()))
        set_setting("Startup", "start_offset", self.start_spinbox_var.get())
        set_setting("Startup", "end_offset", self.end_spinbox_var.get())
        set_setting("Execution", "skip_if_empty", str(self.checkbox5_var.get()))
        set_setting("Execution", "show_browser_window", str(self.checkbox6_var.get()))
        self.on_settings_close()

    def on_settings_close(self):
        if self.on_settings_close_callback:
            self.on_settings_close_callback()
        if self.is_opening_callback:
            self.is_opening_callback = False
        self.grab_release()
        self.destroy()

    def _place_on_top_of_master(self, master):
        master.update_idletasks()
        x = master.winfo_rootx()
        y = master.winfo_rooty()
        self.geometry(f"+{x}+{y}")
        self.deiconify()
        self.lift()
        self.focus_force()

    def on_tab_changed(self, event):
        self.focus_set()
