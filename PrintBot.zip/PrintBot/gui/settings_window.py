import tkinter as tk
import tkinter.ttk as ttk

import config.constants as constants
from utils.common import get_setting, set_setting, open_printers_settings
from gui.style_mixin import StyleMixin


class SettingsWindow(tk.Toplevel, StyleMixin):
    def __init__(self, master, is_opening=None, on_settings_close=None):
        super().__init__(master)
        self.withdraw()
        self.is_opening_callback = is_opening
        self.on_settings_close_callback = on_settings_close
        self.protocol("WM_DELETE_WINDOW", self.on_settings_close)
        self.iconbitmap(constants.SETTINGS_ICO_PATH)

        self.after(0, lambda: self._place_on_top_of_master(master))

        self.title("PrintBot - 設定")

        style = ttk.Style()
        self.set_style_instance(style)
        self.apply_theme("vista")

        self.notebook = ttk.Notebook(self, style="TNotebook")
        self.notebook.pack(fill="both", expand=True, padx=7, ipady=12)

        self.general_frame = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.general_frame, text=" 全般     ")

        self.app_info_frame = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.app_info_frame, text=" 情報    ")

        self.bottom_frame = ttk.Frame(self, style="Gray.TFrame")
        self.bottom_frame.pack(side="bottom", fill="x", padx=6, pady=8)

        self.login_info_lf = ttk.Labelframe(self.general_frame, text="BC受付のログイン")
        self.login_info_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(7, 0), ipadx=12, ipady=5
        )

        self.checkbox1_var = tk.BooleanVar()
        self.checkbox1 = ttk.Checkbutton(
            self.login_info_lf,
            text="ログインに成功した場合、パスワードを保存して次回から自動入力する",
            variable=self.checkbox1_var,
            style="Settings.TCheckbutton",
        )
        self.checkbox1.pack(anchor="w", padx=(19, 0), pady=(7, 2))

        # self.checkbox2_var = tk.BooleanVar()
        # self.checkbox2 = ttk.Checkbutton(
        #     self.login_info_lf,
        #     text="ユーザーIDを変更する (既定のユーザーID : Windows のユーザー名)",
        #     variable=self.checkbox2_var,
        #     style="Settings.TCheckbutton",
        # )
        # self.checkbox2.pack(anchor="w", padx=(19, 0), pady=(7, 2))

        # self.input_user_id_var = tk.StringVar()
        # self.input_user_id = tk.Entry(
        #     self.login_info_lf,
        #     width=36,
        #     textvariable=self.input_user_id_var,
        #     insertwidth=1,
        #     borderwidth=0,
        #     highlightthickness=1,
        #     highlightbackground="#8d8d8d",
        #     highlightcolor="#0078d4",
        # )
        # self.input_user_id.pack(anchor="w", padx=(36, 0), pady=2)

        self.print_target_lf = ttk.Labelframe(self.general_frame, text="印刷範囲")
        self.print_target_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(7, 0), ipadx=12, ipady=5
        )

        self.checkbox3_var = tk.BooleanVar()
        self.checkbox3_var.trace_add("write", self.toggle_date_range)
        self.checkbox3 = ttk.Checkbutton(
            self.print_target_lf,
            text="アプリケーション起動時の日付範囲を変更する",
            variable=self.checkbox3_var,
            style="Settings.TCheckbutton",
        )
        self.checkbox3_var.trace_add("write", self.toggle_date_range)
        self.checkbox3.grid(row=0, column=0, sticky="w", padx=(19, 0), pady=(7, 2))

        self.range_frame = ttk.Frame(self.print_target_lf)
        self.range_frame.grid(row=1, column=0, sticky="w", padx=(36, 0), pady=2)

        self.date_range_label1 = ttk.Label(
            self.range_frame, text="開始日: 当日から", style="Custom.TLabel"
        )
        self.date_range_label1.pack(side="left")

        self.start_spinbox_var = tk.StringVar()
        self.start_spinbox = tk.Spinbox(
            self.range_frame,
            from_=0,
            to=6,
            width=2,
            textvariable=self.start_spinbox_var,
        )
        self.start_spinbox.pack(side="left", padx=(2, 1))
        self.start_spinbox_var.trace_add("write", self.validate_spinbox_range)
        self.start_spinbox.bind("<Key>", self.disable_key_input)

        self.date_range_label2 = ttk.Label(
            self.range_frame, text="日目 / 終了日: 当日から", style="Custom.TLabel"
        )
        self.date_range_label2.pack(side="left")

        self.end_spinbox_var = tk.StringVar()
        self.end_spinbox = tk.Spinbox(
            self.range_frame, from_=0, to=6, width=2, textvariable=self.end_spinbox_var
        )
        self.end_spinbox.pack(side="left", padx=(2, 1))
        self.end_spinbox_var.trace_add("write", self.validate_spinbox_range)
        self.end_spinbox.bind("<Key>", self.disable_key_input)

        self.date_range_label3 = ttk.Label(
            self.range_frame, text="日目", style="Custom.TLabel"
        )
        self.date_range_label3.pack(side="left")

        # self.checkbox4_var = tk.BooleanVar()
        # self.checkbox4 = ttk.Checkbutton(
        #     self.print_target_lf,
        #     text="前回選択した印刷対象を次回起動時に選択状態にする",
        #     variable=self.checkbox4_var,
        #     style="Settings.TCheckbutton",
        # )
        # self.checkbox4.grid(row=2, column=0, sticky="w", padx=(19, 0), pady=(7, 2))

        # self.execute_lf = ttk.Labelframe(self.general_frame, text="印刷実行時の設定")
        # self.execute_lf.pack(
        #     fill="x", expand=True, padx=(15, 17), pady=(7, 0), ipadx=12, ipady=5
        # )

        # self.checkbox5_var = tk.BooleanVar()
        # self.checkbox5 = ttk.Checkbutton(
        #     self.execute_lf,
        #     text="納入予定品がない場合、その印刷をスキップする",
        #     variable=self.checkbox5_var,
        #     style="Settings.TCheckbutton",
        # )
        # self.checkbox5.pack(anchor="w", padx=(19, 0), pady=(7, 2))

        # self.checkbox6_var = tk.BooleanVar()
        # self.checkbox6 = ttk.Checkbutton(
        #     self.execute_lf,
        #     text="自動操作中のウィンドウを表示する",
        #     variable=self.checkbox6_var,
        #     style="Settings.TCheckbutton",
        # )
        # self.checkbox6.pack(anchor="w", padx=(19, 0), pady=(7, 2))

        self.printer_lf = ttk.Labelframe(self.general_frame, text="プリンター設定")
        self.printer_lf.pack(
            fill="x", expand=True, padx=(15, 17), pady=(0, 10), ipadx=12, ipady=6
        )

        self.label1 = ttk.Label(
            self.printer_lf,
            text="Windows の印刷設定を開いて、既定のプリンターなどを設定します。",
            style="Custom.TLabel",
        )
        self.label1.pack(fill="x", padx=(19, 0), pady=(7, 2))

        self.printer_settings_button = ttk.Button(
            self.printer_lf,
            text="プリンター設定を開く",
            style="Custom.TButton",
            command=open_printers_settings,
        )
        self.printer_settings_button.pack(side="right", padx=10, pady=(2, 5), ipadx=8)

        self.app_info_lf = ttk.Labelframe(
            self.app_info_frame, text="このアプリケーションについて"
        )
        self.app_info_lf.columnconfigure(2, weight=1)
        self.app_info_lf.pack(fill="x", expand=True, padx=14, pady=(0, 6), ipady=5)

        self.label2 = ttk.Label(
            self.app_info_lf, text="アプリケーション名 :", style="Custom.TLabel"
        )
        self.label2.grid(row=0, column=0, sticky="w", padx=(19, 0), pady=2)

        self.label3 = ttk.Label(
            self.app_info_lf, text=constants.APP_NAME, style="Custom.TLabel"
        )
        self.label3.grid(row=0, column=1, sticky="w", padx=(6, 0))

        self.label4 = ttk.Label(
            self.app_info_lf, text="バージョン :", style="Custom.TLabel"
        )
        self.label4.grid(row=1, column=0, sticky="w", padx=(19, 0), pady=2)

        self.label5 = ttk.Label(
            self.app_info_lf, text=constants.APP_VERSION, style="Custom.TLabel"
        )
        self.label5.grid(row=1, column=1, sticky="w", padx=(6, 0))

        self.label6 = ttk.Label(
            self.app_info_lf, text="最終更新日 :", style="Custom.TLabel"
        )
        self.label6.grid(row=2, column=0, sticky="w", padx=(19, 0), pady=2)

        self.label7 = ttk.Label(
            self.app_info_lf, text=constants.LAST_UPDATE, style="Custom.TLabel"
        )
        self.label7.grid(row=2, column=1, sticky="w", padx=(6, 0))

        self.label8 = ttk.Label(
            self.app_info_lf, text="作成者 :", style="Custom.TLabel"
        )
        self.label8.grid(row=3, column=0, sticky="w", padx=(19, 0), pady=2)

        self.label9 = ttk.Label(
            self.app_info_lf, text=constants.APP_CREATOR, style="Custom.TLabel"
        )
        self.label9.grid(row=3, column=1, sticky="w", padx=(6, 0))

        self.label10 = ttk.Label(
            self.app_info_lf, text=constants.EMAIL_ADDRESS, style="Custom.TLabel"
        )
        self.label10.grid(row=4, column=1, sticky="w", padx=(6, 0), pady=2)

        self.address_button = ttk.Button(
            self.app_info_lf,
            width=18,
            text="メールアドレスをコピー",
            command=self.copy_to_clipboard,
            style="Custom.TButton",
        )
        self.address_button.grid(row=5, column=1, sticky="w", padx=(6, 0), pady=(8, 2))

        self.close_button = ttk.Button(
            self.bottom_frame,
            text="キャンセル",
            command=self.on_settings_close,
        )
        self.close_button.pack(
            side="right",
            ipadx=8,
        )

        self.save_button = ttk.Button(
            self.bottom_frame,
            text="OK",
            command=self.save_settings,
        )
        self.save_button.pack(side="right", padx=6, ipadx=10)

        self.load_settings()

        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

    def on_settings_close(self):
        """設定ウィンドウを閉じたときの動作"""
        if self.on_settings_close_callback:
            self.on_settings_close_callback()
        if self.is_opening_callback:
            self.is_opening_callback = False
        self.grab_release()
        self.destroy()

    def _place_on_top_of_master(self, master):
        """呼び出し元のウィンドウの上にウィンドウを出す"""
        master.update_idletasks()
        x = master.winfo_rootx()
        y = master.winfo_rooty()
        w = master.winfo_width()
        h = master.winfo_height()
        self.geometry(f"+{x}+{y}")
        self.deiconify()
        self.lift()
        self.focus_force()

    def on_tab_changed(self, event):
        self.focus_set()

    def toggle_date_range(self, *args):
        if self.checkbox3_var.get():
            self.date_range_label1.config(state="normal")
            self.start_spinbox.config(state="normal")
            self.date_range_label2.config(state="normal")
            self.end_spinbox.config(state="normal")
            self.date_range_label3.config(state="normal")
        else:
            self.date_range_label1.config(state="disabled")
            self.start_spinbox.config(state="disabled")
            self.date_range_label2.config(state="disabled")
            self.end_spinbox.config(state="disabled")
            self.date_range_label3.config(state="disabled")

    def disable_key_input(self, event):
        return "break"

    def validate_spinbox_range(self, *args):
        start = self.start_spinbox_var.get()
        end = self.end_spinbox_var.get()
        if end < start:
            self.end_spinbox_var.set(start)

    def copy_to_clipboard(self):
        """クリップボードにテキストをコピーする"""
        text = constants.EMAIL_ADDRESS
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update()

        self.address_button.config(text="コピーしました", state="disabled")
        self.after(2000, self.reset_button)

    def reset_button(self):
        """ボタンを元に戻す"""
        self.address_button.config(text="メールアドレスをコピー", state="normal")

    def load_settings(self):
        """INIファイルから設定を読み込む"""
        self.checkbox1_var.set(get_setting("Login", "save_password", "False") == "True")

        # self.checkbox2_var.set(
        #     get_setting("Login", "change_user_id", "False") == "True"
        # )
        # self.input_user_id_var.set(get_setting("Login", "custom_user_id", ""))

        self.checkbox3_var.set(
            get_setting("Startup", "change_date_range", "False") == "True"
        )
        self.start_spinbox_var.set(int(get_setting("Startup", "start_offset", "0")))
        self.end_spinbox_var.set(int(get_setting("Startup", "end_offset", "0")))

        # self.checkbox4_var.set(
        #     get_setting("Startup", "reuse_previous_selection", "False") == "True"
        # )

        # self.checkbox5_var.set(
        #     get_setting("Execution", "skip_if_empty", "False") == "True"
        # )
        # self.checkbox6_var.set(
        #     get_setting("Execution", "show_window", "False") == "True"
        # )

    def save_settings(self):
        """INIファイルに設定を保存する"""
        set_setting("Login", "save_password", str(self.checkbox1_var.get()))

        # set_setting("Login", "save_password", str(self.checkbox1_var.get()))
        # set_setting("Login", "change_user_id", str(self.checkbox2_var.get()))
        # set_setting("Login", "custom_user_id", self.input_user_id_var.get())

        set_setting("Startup", "change_date_range", str(self.checkbox3_var.get()))
        set_setting("Startup", "start_offset", str(self.start_spinbox_var.get()))
        set_setting("Startup", "end_offset", str(self.end_spinbox_var.get()))

        # set_setting(
        #     "Startup", "reuse_previous_selection", str(self.checkbox4_var.get())
        # )

        # set_setting("Execution", "skip_if_empty", str(self.checkbox5_var.get()))
        # set_setting("Execution", "show_window", str(self.checkbox6_var.get()))

        self.on_settings_close()
