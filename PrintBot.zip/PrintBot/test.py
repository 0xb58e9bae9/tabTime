import tkinter as tk
import subprocess


def open_printers_settings():
    subprocess.run(["start", "ms-settings:printers"], shell=True)


root = tk.Tk()
root.title("設定を開く")
root.geometry("300x100")

btn = tk.Button(
    root, text="プリンターとスキャナーを開く", command=open_printers_settings
)
btn.pack(pady=20)

root.mainloop()
